﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Ткани
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int visiblePass = 0;
        Entities.trade5Entities entities;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btAutorizatia_Click(object sender, RoutedEventArgs e)
        {
            entities = App.DBManager;
            var user = entities.User.Where(c => c.UserLogin == tbLogin.Text);
            if (user != null)
            {
                foreach (var c in user)
                {
                    int role = c.UserRole;
                    string firstName = c.UserName;
                    string lastName = c.UserSurname;
                    string patronymicName = c.UserPatronymic;
                    if (visiblePass == 0)
                    {
                        if (pbPassword.Password == c.UserPassword)
                        {
                            Forms.UserForm uF = new Forms.UserForm(firstName, lastName, patronymicName, role);
                            uF.Show();
                            Close();
                        }
                        else MessageBox.Show("Введенные данные неверные");
                    }
                    else if (visiblePass == 1)
                    {
                        if (tbPassword.Text == c.UserPassword)
                        {
                            Forms.UserForm uF = new Forms.UserForm(firstName, lastName, patronymicName, role);
                            uF.Show();
                            Close();
                        }
                        else MessageBox.Show("Введенные данные неверные");
                    }
                }
            }
            else MessageBox.Show("Такого пользователя не существует");
        }

        private void btGost_Click(object sender, RoutedEventArgs e)
        {
            Forms.FormGost fG = new Forms.FormGost();
            fG.Show();
            Close();
        }

        private void btRegistration_Click(object sender, RoutedEventArgs e)
        {

        }
        private void checkPass_Click(object sender, RoutedEventArgs e)
        {
            if (visiblePass == 0)
            {
                tbPassword.Text = pbPassword.Password;
                tbPassword.Visibility = Visibility.Visible;
                pbPassword.Visibility = Visibility.Hidden;
                visiblePass = 1;
            }
            else if (visiblePass == 1)
            {
                pbPassword.Password = tbPassword.Text;
                pbPassword.Visibility = Visibility.Visible;
                tbPassword.Visibility = Visibility.Hidden;
                visiblePass = 0;
            }
        }
    }
}
