﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Security.Cryptography.Xml;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Serialization;
using Ткани.Entities;

namespace Ткани.Forms
{
    /// <summary>
    /// Логика взаимодействия для AddProduct.xaml
    /// </summary>
    public partial class AddProduct : Window
    {
        string article;
        Product import;
        trade5Entities Database;
        public AddProduct(trade5Entities entities, Product DataBase, string title)
        {
            InitializeComponent();
            tbkTitle.Text = title;
            cbSupplier.ItemsSource = App.DBManager.Product.ToList();
            cbCategory.ItemsSource = App.DBManager.Product.ToList();
            if (title == "Редактирование продукта")
            {
                import = DataBase;
                this.DataContext = import;
            }
        }

        private void btAdd_Click(object sender, RoutedEventArgs e)
        {
            if (tbkTitle.Text == "Добавление продукта")
            {
                trade5Entities entity = new trade5Entities();
                if (tbName.Text == null)
                {
                    MessageBox.Show("Название не может быть пустым");
                }
                else if (tbArticle.Text == null)
                {
                    MessageBox.Show("Артикул не может быть пустым");
                }
                else if (tbDescription.Text == null)
                {
                    MessageBox.Show("Описание не может быть пустым");
                }
                else if (cbCategory.Text == null)
                {
                    MessageBox.Show("Категория не может быть пустой");
                }
                else if (cbSupplier.Text == null)
                {
                    MessageBox.Show("Поставщик не может быть пустым");
                }
                else if (tbCost.Text == null)
                {
                    MessageBox.Show("Цена не может быть пустой");
                }
                else
                {
                    string category = cbCategory.Text;
                    int price = Convert.ToInt32(tbCost.Text);
                    var import = new Product
                    {
                        ProductArticleNumber = tbArticle.Text,
                        ProductCategory = category,
                        ProductName = tbName.Text,
                        ProductDescription = tbDescription.Text,
                        ProductManufacturer = cbCategory.Text,
                        ProductCost = price,
                        ProductPhoto = "picture.png"
                    };
                    entity.Product.Add(import);
                    entity.SaveChanges();
                    MessageBox.Show("Данные сохранены");
                }
            }
            else
            {
                Database.SaveChanges();
                this.Close();
            }
        }

        private void btCancel_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
