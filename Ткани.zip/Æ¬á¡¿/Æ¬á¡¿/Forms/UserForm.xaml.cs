﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Ткани.Entities;

namespace Ткани.Forms
{
    /// <summary>
    /// Логика взаимодействия для UserForm.xaml
    /// </summary>
    public partial class UserForm : Window
    {
        int roleUser;
        string surnameUser;
        string firstNameUser;
        string patronymicUser;
        public UserForm(string firstname, string surname, string patronymic, int role)
        {
            InitializeComponent();
            dgProducts.ItemsSource = App.DBManager.Product.ToList();
            roleUser = role;
            surnameUser = surname;
            firstNameUser = firstname;
            patronymicUser = patronymic;
            tbkTime.Text = "Добро пожаловать " + surname + " " + firstname + " " + patronymic+"\n" + DateTime.Now.ToString();
            if (roleUser == 2 || roleUser == 3)
            {
                btAdd.Visibility = Visibility.Hidden;
                btDel.Visibility = Visibility.Hidden; 
                btEdit.Visibility = Visibility.Hidden;
            }
        }

        private void btExit_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mw = new MainWindow();
            mw.Show();
            Close();
        }

        private void btAdd_Click(object sender, RoutedEventArgs e)
        {
            string title = "Добавление продукта";
            var delpayClient = dgProducts.SelectedItem as Entities.Product;
            AddProduct addP = new AddProduct(App.DBManager, delpayClient, title);
            addP.ShowDialog();
        }

        private void btDel_Click(object sender, RoutedEventArgs e)
        {
            //Удаление продукта
            var rowselected = dgProducts.SelectedItem as Entities.Product;

            if (rowselected == null)
            {
                MessageBox.Show("Не выбрана ни одна строка для удаления!");
                return;
            }

            MessageBoxResult result = MessageBox.Show("Вы уверены, что хотите удалить товар?", "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                App.DBManager.Product.Remove(rowselected);
                App.DBManager.SaveChanges();
                dgProducts.ItemsSource = App.DBManager.Product.ToList();
            }
        }

        private void btEdit_Click(object sender, RoutedEventArgs e)
        {
            string title = "Редактирование продукта";
            dgProducts.ItemsSource = App.DBManager.Product.ToList();
            var delpayClient = dgProducts.SelectedItem as Entities.Product;
            if (delpayClient != null)
            {
                var addNewBook = new AddProduct(App.DBManager, delpayClient, title);

                addNewBook.ShowDialog();
            }
            else MessageBox.Show("Выберите строчку из списка для редактирования");
        }
    }
}
